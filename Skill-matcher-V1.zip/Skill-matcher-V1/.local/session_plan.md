# Objective
Fix sign-in authentication flow. The OIDC redirect to replit.com is being blocked (refused to connect). The callback never reaches the server. Need to fix the cookie settings and ensure the auth flow works end-to-end.

# Tasks

### T001: Fix session cookie settings and add comprehensive auth debugging
- **Blocked By**: []
- **Details**:
  - Revert `secure: 'auto'` back to `secure: true` (express-session doesn't support 'auto')
  - Change `sameSite` from `'lax'` to `'none'` — the OIDC callback is a cross-origin redirect from replit.com back to our domain, and the browser may not send the session cookie with sameSite=lax in this context
  - With sameSite=none + secure=true, the cookie will be sent on cross-origin redirects (required for OIDC flows)
  - Add a debug endpoint `GET /api/debug-auth` that returns session info, cookie settings, and environment status (non-sensitive) to help diagnose issues
  - Add error handling in the Strategy's `authorizationRequest` override to catch and log redirect failures
  - Files: `auth.js`
  - Acceptance: Session cookie is correctly sent during the OIDC callback redirect; auth flow completes

### T002: Fix login page to properly handle both iframe and direct access
- **Blocked By**: []
- **Details**:
  - When in iframe: show a clear message explaining the user needs to open in a new tab, with a button that copies the URL or opens the full app URL (not /api/login) in a new tab
  - When NOT in iframe (direct browser): keep the normal login button that navigates directly to /api/login
  - Remove the "waiting for sign-in" polling approach since it adds complexity and may not work with cross-origin cookie issues
  - Files: `public/login.html`
  - Acceptance: Login button works correctly in both iframe and direct browser contexts
